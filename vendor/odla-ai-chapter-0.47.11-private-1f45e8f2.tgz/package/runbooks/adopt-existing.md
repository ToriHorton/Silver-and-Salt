# Adoption runbook: convert an existing site to Chapter

Audience: an LLM or coding agent converting an existing or deployed website,
Worker, database, auth flow, or operating membership product.

Read this file completely before changing the application. Also read the
installed package `README.md`, `package.json` exports, and `dist/*.d.ts`. The
existing product stays live until measured Chapter parity and cutover are
approved.

If the repository is empty and no operating state exists, use
[`greenfield.md`](./greenfield.md).

## Completion means conversion, not installation

The following are canary evidence only:

- installing `@odla-ai/chapter`;
- writing `defineChapter()` or rendering `ChapterAdmin`;
- provisioning an ODLA tenant;
- serving a login screen or one Chapter API route;
- deploying a parallel Worker with copied sample data.

Adoption is complete only when the real product routes and journeys use Chapter
as the primary implementation, live data is reconciled and continuously
handled, production reads and writes have crossed explicit gates, and both
runtime and data rollback remain proven.

## Non-negotiable boundaries

1. Never mutate, reset, delete, detach, or repoint current production resources
   during development adoption. Preserve Workers, Pages projects, domains,
   databases, R2/KV, queues, Workflows, cron, webhooks, Clerk, Stripe, email,
   Google calendars, source repositories, and immutable history.
2. Never print or commit secrets. Dev and production use separate credentials
   and explicitly targeted Worker environments.
3. Preserve existing public URLs, content, SEO, header/navigation, responsive
   layout, theme behavior, accessibility, and branded assets unless the human
   approves a product change. Framework replacement is not redesign authority.
4. Preserve data semantics before deleting code. Chapter schema, routes, sends,
   auth, account, payment, and scheduling defaults are hypotheses until parity
   tests prove them.
5. Runtime rollback and data rollback are different. Restoring an old Worker
   cannot recover writes accepted after Chapter became authoritative.
6. No silent fallback. A Chapter-primary failure is explicit and measured; a
   legacy fallback, if approved, is named, time-bounded, and visible.
7. Keep ODLA rules default-deny and every admin/provider mutation
   server-mediated.

## Phase 0 — Freeze the operating baseline

Use odla PM as the migration's durable coordination state; do not create a
parallel migration diary. If the odla app already exists, begin with `pm next`
plus open bugs and recent decisions for the `appId` from `odla.config.mjs`.
Read the active task, its linked goal, and their comments before inspecting
code. If the requested work is not aligned to an open goal, discuss that with
the human before implementation. Refine and mark the task Ready, then claim its
reviewed revision atomically before creating the execution worktree.

If the app is not registered yet, choose the intended stable `appId`, keep
Phase 0/early provisioning evidence in focused commits and checkpoint
handoffs, and rerun the inventory when a fresh agent resumes. Old branches,
git history, unrelated deployments, and earlier experiments are only leads to
verify. Immediately after the first provision registers the app, create PM
goals/tasks/decisions and backfill the approved baseline evidence; PM is
authoritative from then on.

Use one conformance goal per acceptance outcome, parallel tasks for independent
tracks, decisions for product/data/identity/route/rollback choices, and bugs
for defects. Comments carry the source commit, immutable deployment version,
verification command/result, and rollback checkpoint. Never put secrets in PM.

### Inventory the product

- every public, member, admin, API, webhook, health, asset, feed, and 404 route;
- current production/dev origins, Worker/Pages names and version ids, routes,
  DNS, compatibility settings, build automation, and rollback versions;
- D1/SQL/ODLA/KV/R2/files and every reader/writer;
- queues, Workflow definitions, cron, provider webhooks, retry/outbox behavior;
- Clerk app/instances, JWT claims, roles/allowlists, redirects, and first-admin
  process;
- Stripe products/prices/webhooks/idempotency, Google calendars, Email Service;
- current schema/rules, row counts, earliest/latest timestamps, natural keys,
  relations, projections, and owner-edited fields;
- public/private content boundaries and every raw HTML/Markdown/inline-JSON
  render sink;
- telemetry, freshness/error alerts, deploy commands, and CI auto-deploys.

For every route, record the method/path, current consumer, owning implementation
(`legacy`, Chapter, or an explicit host adapter), request and response schemas,
status/error/auth/cache behavior, and its evidence. Source evidence names the
checked-in path plus commit; deployment evidence names the origin plus immutable
Worker/deployment version. A response observed on an unversioned deployment
describes only that deployed build at that moment. It does not establish route
ownership or the contract of the branch being changed. Treat old branches, git
history, and unrelated deployments as leads to verify, never as the migration
specification.

### Freeze visual and behavior evidence

Capture representative production screenshots and measured layouts at 390,
768, 1280, and 1440 pixels in every supported theme. Record:

- header height, wordmark/nav alignment, responsive breakpoints, page geometry;
- form fields/labels/errors, Clerk containment, tables/cards/rails, loading,
  empty, error, unauthorized, and 404 states;
- full public route/link inventory, titles, descriptions, canonical URLs,
  structured data, robots/sitemap/feed behavior;
- join, payment, booking, member, admin, CRM, email, and refund journeys.

Do not rely on visual memory. These fixtures are acceptance authority until a
human explicitly approves a redesign.

### Define migration budgets

Record accepted count/hash differences, maximum sync lag/newest-data age, route
and status parity, latency/error budget, visual tolerances, identity merge
policy, deterministic synthetic user/application ids, and an observation
window. Record both rollback plans before any Chapter write.

Maintain a migration matrix:

| Track | Legacy authority | Chapter/ODLA dev target | Current reads | Current writes | Evidence/freshness | Rollback | State |
| --- | --- | --- | --- | --- | --- | --- | --- |
| runtime/bindings | | | | | | | |
| membership data/CRM | | | | | | | |
| jobs/webhooks/outboxes | | | | | | | |
| Clerk/auth | | | | | | | |
| Stripe/payments | | | | | | | |
| calendar/booking | | | | | | | |
| email | | | | | | | |
| public/member/admin UI | | | | | | | |
| o11y/alerts | | | | | | | |

Allowed states: `not-started`, `canary`, `parallel`, `verified`,
`primary-dev`, `primary-prod`, `retired`, or `n/a` with a reason.

## Phase 1 — Model Chapter without deleting anything

Install the version-matched agent guidance and inspect the automation boundary:

```sh
npm install \
  @odla-ai/chapter @odla-ai/brand @odla-ai/ui \
  @odla-ai/crm @odla-ai/db \
  @odla-ai/calendar @odla-ai/email \
  @odla-ai/auth-clerk @odla-ai/o11y \
  jose preact
npm install --save-dev \
  @odla-ai/cli @odla-ai/security \
  @cloudflare/workers-types \
  typescript vite vitest wrangler
npx odla-ai setup
npm ls @odla-ai/chapter @odla-ai/crm @odla-ai/ui @odla-ai/cli
npx odla-ai capabilities --json
```

Use normal dependency declarations while ODLA is under active development.
Review and commit `package.json` plus `package-lock.json`, use `npm ci` after
the intentional dependency update, record resolved versions in PM, and rerun
the frozen acceptance and Chapter conformance suites. Do not use
`--legacy-peer-deps` or preserve an incompatible peer.

Write `src/chapter.config.mjs` from the inventory. Make every behavior decision
explicit:

- `mode`, `services`, complete light/dark/invert brand tokens and copy contract;
- price/currency/interval and owner-approved policy copy;
- email addresses/templates/debug redirect and send trigger;
- scheduling/timezone and pipeline stages/bookable/approvable subsets;
- exact application fields, caps, disclaimer requirement, Clerk-visible
  `profileFields`, and CRM-projected `crmFields`;
- claim/table auth, ladder/super-admin tier;
- account side effect (`none`, `create`, or emailed `invite`);
- approve/refund policy and any network targets/field allowlists;
- any separately delegated `signupControl` source, environment/Stripe-mode
  boundary, durable hub outbox, follower last-known-good revision, and rollback
  history (never smuggle this authority through the CRM network route);
- for a leader, the existing CRM config passed through
  `leaderCrmConfig({ base })`, the public formation field allowlist, and the
  Dashboard/People/Portfolio/Settings workspace composition.

### Schema/rule parity gate

Before deleting old schema/rules/provisioning:

1. freeze the legacy schema and rules from an exact reviewed source path and
   commit, with a recorded content digest;
2. make that baseline independent: use the untouched legacy source or a literal
   fixture that does not import Chapter, the active descriptor/schema alias, or
   another generated candidate; do not modify baseline and candidate in the
   same approval;
3. normalize only approved representational differences;
4. compare `createChapterIntegration(chapter)` namespaces, attrs, links, rules,
   and seeds to the independent baseline;
5. run a negative control by removing or changing a known field/rule on one side
   and prove the parity test fails before trusting a green result;
6. fail on missing fields, widened rules, cardinality changes, renamed natural
   keys, new client-readable data, or unapproved seed differences;
7. record every intentional delta and migration mapping as a PM decision, and
   attach the comparator evidence to the linked conformance goal/task.

`createChapterIntegration()` inserts the group seed only when absent. Existing
runtime owner edits do not update from later config changes. Compare the current
group row field by field, classify ownership, and write an explicit migration
for approved differences.

### Behavior-delta gate

At minimum audit:

- services default (`db`, `calendar`, `o11y`);
- per-field and request-body caps;
- explicit chapter-mode account decision and outbound effects of
  `create`/`invite`;
- stock `JoinIsland` keeps one `submissionId` across an ambiguous lost-response
  retry. Prove the replay returns the original canonical application id, that
  the id can resume the journey, and that no second row or side effect exists;
- `profileFields` now defaults to `[]`; enumerate the small account/admin
  signals that may be mirrored into backend-only Clerk private metadata rather
  than relying on implicit projection. Keep the application row and CRM
  canonical;
- application-to-CRM projection fields;
- leader target ids exactly match follower `chapter.id` values;
- app-to-app requests use the signed v2 source envelope, transmit no share
  secret, Clerk token, or ODLA key, and reject a sender/source mismatch;
- `crm_record_origin` and `crm_record_delivery` are present in schema parity,
  retries preserve identity, and aggregate rollups expose partial failure
  without returning record fields;
- public formation retries retain one stable `submissionId`, reject
  non-allowlisted/internal fields, and converge on one CRM record;
- `requireDisclaimerAck` now defaults to `true`; set `false` explicitly only
  when the existing product has no consent control, and preserve
  `disclaimerAckAt`;
- initial/bookable/approvable stages and never-backwards transitions;
- when each lifecycle email fires;
- Chapter recognizes only the literal `prod` environment as live mail; the
  CLI-valid alias `production` follows the non-production fail-safe;
- approve promotion/email and refund/subscription behavior;
- Chapter route names and member/admin routing;
- Chapter's insert-only group seed and runtime-edited fields;
- payment readiness versus actual webhook readiness;
- calendar's HTTP-200 `schedulingReady: false` degradation.

The stock `applications` namespace is fixed. Its configurable form strings are
limited to `firstName`, `lastName`, `email`, `referral`, `referralName`,
`whoYouAre`, `linkedin`, `message`, `phone`, and `state`; `focus` and
`disclaimerAck` are special. An unknown configured field can pass config
validation and then fail at the database. Preserve a host schema/submit route
for every legacy field that cannot be mapped without loss.

The current `prices.currency` and `prices.interval` values do not control
storage, join config, formatting, or the Stripe subscription. Treat the live
Stripe Price as authoritative and make provider-side amount/currency/interval
equality a cutover gate.

Keep one test per accepted behavior decision so a package upgrade cannot change
the site silently.

### Make the dev descriptor executable

Before Phase 2, create or adapt `odla.config.mjs`. A repository with no ODLA
config may use the installed exact CLI's `init` command as a starting point,
but the reviewed result must declare:

- the existing product's one app id/name and only `envs: ["dev"]`;
- explicit `chapter.services`;
- `integrations: [createChapterIntegration(chapter)]` plus any compatible,
  non-overlapping host integrations;
- the intended dev Clerk publishable key, calendar ids, o11y service, local
  credential paths, and a null/off-route dev link.

Do not provision both a legacy inline schema and the Chapter integration for the
same namespaces. After the schema/rule parity gate passes, freeze the legacy
descriptor as a test fixture and make the reviewed Chapter integration the
active dev descriptor. Production configuration remains absent.

Create an off-route dev Worker entry using
`chapterWorker({ chapter, routes: legacyRoutes })`, wrapped with o11y, and an
explicit `wrangler ... --env dev` target. Keeping all legacy handlers as host
routes at this point changes no route ownership; it only makes the canary and
Chapter data surface executable.

### Add a fail-closed migration readiness route

The built-in `/api/health` is only `{ "ok": true }`; it does not touch the
database. Add an admin-only host route or executable command that returns `503`
until all of these match the acceptance manifest:

- literal tenant/app/env and Chapter/package release;
- expected schema/rules digest and required group/config rows;
- reconciled counts, natural-key collisions, relation integrity, and newest
  source timestamp within the freshness budget;
- zero unhandled quarantines and bounded/zero pending outbox work;
- healthy continuous sync and the Chapter-primary-to-legacy rollback mirror.

Return only redacted counts/digests. This gate is allowed to fail during initial
canary work; it must be mechanically green before switching either reads or
writes, and after every rollback recovery.

## Phase 2 — Create an isolated dev canary

Run:

```sh
npx odla-ai doctor
npx odla-ai provision --dry-run
```

The dev topology must be distinct from production:

- `envs: ["dev"]`, tenant `<app-id>--dev`;
- explicit dev Worker name and `wrangler ... --env dev`;
- no production route, DNS, database binding, queue, Workflow, cron, webhook,
  Git writer, Stripe live resource, email recipient, or Google write authority;
- `debugEmail` enabled and Stripe test mode only;
- dev Clerk `pk_test_...` from the intended workspace/application;
- o11y wrapped around the real canary handler with safe low-cardinality labels.

Show the dry-run target, schema/rules, services, link, and secret recipients.
After the human approves the device code:

```sh
npx odla-ai provision --email <existing-odla-account> --write-dev-vars --push-secrets
npm run build
npx wrangler deploy --env dev
npx odla-ai smoke --env dev
```

If credential transfer alone must be retried, use the non-rotating
`npx odla-ai secrets push --env dev`; do not reprovision or rotate by default.
Verify the deployed Chapter health marker, a database-backed read, and an
unauthenticated private-route rejection. Record the URL and Cloudflare version
id. A canary advances matrix rows only to `canary`; the migration-readiness
route is expected to remain `503` until Phase 3 evidence passes.

## Phase 3 — Adopt data with replay and reconciliation

Skip historical backfill only when the human-approved inventory proves the
site has no operating data. Otherwise:

1. Write a checked-in mapping for every legacy table/collection/file and
   relation: natural key, target namespace, attrs, omissions/nulls, edge
   direction, ownership, tombstone/deletion behavior, and provenance.
2. Freeze a source snapshot or bounded high-water mark. Record counts,
   earliest/latest timestamps, and a digest/immutable id.
3. Backfill in bounded deterministic chunks using stable mutation ids.
   Persist checkpoints and a rejection ledger; each input is written, skipped
   with reason, or failed/retryable.
4. Replay from an earlier checkpoint and prove no duplicate applications,
   people, companies, meetings, email log entries, relations, or side effects.
5. Generate a redacted reconciliation report: counts, required attrs, duplicate
   natural keys, dangling relations, identity collisions, status/price/role
   differences, and newest timestamps.
6. Preserve human-owned fields. Automated projection omits fields it does not
   own rather than reading and writing stale copies.

### Continuous operation

Choose one durable event boundary for production-shaped changes. New legacy
applications, payments, role changes, meetings, CRM edits, and emails must reach
the dev Chapter projection through a measured outbox/queue/replay process.
Record oldest pending age, attempts, quarantine, and source-to-target lag.

Backfill alone is not conversion. Advance to `continuously-synced` only after
normal schedules/webhooks are observed and failures replay from durable state.

### Shadow reads

For list/detail/search/admin dashboard/member status/join config, read both
legacy and Chapter in dev while still serving the legacy response. Compare
normalized status, ids, ordering, counts, fields, relations, price/policy, and
freshness. Log bounded diffs, never private row bodies.

At separate human checkpoints:

1. switch dev reads to Chapter and make failures explicit;
2. switch accepted dev writes to Chapter;
3. durably mirror Chapter-primary writes back to the legacy rollback authority;
4. simulate ODLA unavailable and rollback-mirror unavailable.

Every authenticated/admin mutator must use this authority contract or be
disabled. A separate Chapter demo route does not satisfy primary-dev.

## Phase 4 — Adopt the Worker and routes in safe order

Do not replace schema, worker, routes, and UI in one unreviewable change.

1. Re-assert that the active dev descriptor is the reviewed
   `createChapterIntegration(chapter)` from Phase 1 and that the legacy
   provisioner remains only as a parity fixture.
2. Start from the off-route `chapterWorker({ chapter, routes })` canary. Host
   routes run before built-ins and receive Chapter's existing context
   (`verifyUser`, `makeDb`, `roleFor`, `isAdmin`); do not verify JWTs twice.
3. Initially keep every bespoke endpoint as a host route. Alias legacy URLs to
   Chapter behavior only when the route-contract matrix proves method, auth,
   request body, response status, JSON keys/types/nesting, units, null/omission
   semantics, and relevant headers are compatible. Matching business values
   alone is not response-shape parity.
4. When contracts differ, keep the legacy route until its consumer adopts the
   packaged Chapter component end to end, or add an explicit adapter with
   contract tests. Do not simply repoint the existing browser code.
5. In Chapter 0.25, `/api/join-config` is Chapter-owned and returns the
   group-scoped join configuration, raw cent values, policy copy, and readiness;
   it is not a promise to reproduce a legacy route's prebuilt Stripe line items
   or publishable key. `JoinIsland` delegates payment to `PaymentStep`, which
   obtains `clientSecret`, `publishableKey`, and `lineItems` from
   `POST /api/payments/subscription` after application submission and refund
   acknowledgement. Verify this installed-version contract before retiring a
   legacy join route.
6. Compare built-in and legacy behavior route by route; only then remove a host
   route that Chapter fully owns and whose consumers use the verified Chapter
   contract or adapter.
7. Keep static fallback and API handling explicit so unknown APIs cannot fall
   through to a successful SPA document.

Test public/private method policies, body limits, idempotency, auth 401 vs 403,
safe redirects, webhook signatures/replay, scheduling conflict,
replay-deduplicated and concurrent email sends, and unavailable-provider
degradation. Chapter's email log prevents a later replay after success; it does
not serialize two concurrent sends, so preserve a stricter existing outbox or
provider-idempotency contract.

## Phase 5 — Adopt UI without losing the product

### Preserve first

Render the Chapter component beside the current implementation in a dev-only
fixture. Compare markup/behavior and the Phase 0 screenshots before deletion.

Before replacing any existing admin workspace, build a feature-level matrix.
Top-level labels and route ids are inventory keys, not parity evidence. For each
workspace record summaries, search/filter/sort/pagination, selection and deep
links, roles and permission signals, record tabs, mutations and provider side
effects, and loading/empty/error/unauthorized/keyboard/responsive states.
Classify every row as packaged-equivalent, composed through a documented seam,
an explicit PM-approved delta, or blocked.

- Import the existing public theme plus its `scope.css`,
  `@odla-ai/ui/index.css`, and `@odla-ai/crm/ui.css` before host CSS.
- Map the legacy semantic design roles into `brand.tokens` and `tokensDark`;
  reserve `palette` / `paletteDark` for custom properties without a typed role.
  Do not carry an unbounded parallel theme system.
- Public pages remain site-owned. Preserve their content hierarchy, imagery,
  URLs, SEO, and responsive geometry.
- Replace join orchestration with `JoinIsland`, member behavior with
  `MembersArea`, and admin with `<ChapterAdmin chapter={chapter}/>` only after
  field/auth/action parity.
- Move the existing voice standard into the recursively partial `copy`
  contract. Snapshot `chapter.copy` and test banned punctuation or required
  terminology; do not leave packaged strings as an unreviewed second voice.
- Preserve the join composition through `renderStepHeader`, `renderSubmit`,
  and `renderDone`; carry Stripe `appearance`/`fonts` and site-owned price/trust
  content into the payment step. Preserve the provisional member card through
  `renderProvisional`.
- Resume redirect-interrupted journeys through the canonical
  `GET /api/join/resume?application=<id>` state or a trusted `loadResume`
  adapter. Do not let raw redirect query flags choose a UI step.
- Preserve the site's global header with the default `chrome="embedded"`;
  use `chrome="standalone"` only when Chapter should supply the masthead, or
  `renderHeader` when the header belongs inside the Chapter scope. Chapter mode
  defaults to Dashboard, People, and Settings; move former global Billing,
  Calendar, Email, and per-record operations into nested tabs.
- Preserve distinctive People summary content, list presentation, record
  heading, and specialized panels with `collectionSection`'s `renderSummary`,
  `renderMaster`, `renderDetailHeader`, and record-tab slots. These slots
  customize content; they do not fix pane geometry.
- The safe first cutover for a validated custom workspace is a `workspaces`
  transform that matches its exact default id, spreads the default metadata,
  and replaces only `render` with the existing component. Fail closed if the
  expected id disappears. Keep an integration test proving the host component
  and representative summary, exploration, role, and operation affordances
  render. Migrate those behaviors into `collectionSection` or `peopleSection`
  slots incrementally; delete the old component only after every matrix row and
  the deployed journey pass.
- Operational usability is not pixel parity with a cramped legacy admin. At
  desktop widths, the unselected People collection must use the full workspace
  width; after a record opens it becomes master/detail. This is the
  `collapseClosedDetail` default. Set it to `false` only when the empty detail
  pane contains intentional, useful content approved by the human.
- Application-backed pipeline changes must use a lifecycle adapter that invokes
  the authoritative application endpoints. Prove approve/refund/manual
  transition side effects; a raw CRM `setStage` is not parity.
- Accept old query/path admin links as inbound compatibility URLs, but generate
  canonical fragment links such as
  `/admin/#people/person/record-id/profile`. Prove refresh, back/forward, and
  signed-out return behavior before removing old routing code.
- Use `brand.accent` or `AdminWorkspace.accent` only when the selected UI theme
  supplies that named family. For a custom compiled brand, use
  `chapterBrandFromTokens(compileBrandTokens(...))` so light, dark, chart, and
  invert roles move together.
- The host still supplies member CSS and the Clerk wrapper around
  `MembersArea`; Chapter does not ship a whole public stylesheet.
- Scope host form styles. Bare `input`, `button`, `select`, `textarea`, `label`,
  or global box-model rules must not corrupt Clerk/vendor DOM.

### Required visual acceptance

At 390, 768, 1280, and 1440 pixels in every theme, compare:

- identical product header/navigation position between public/member/admin;
- wordmark, text baseline, theme control, active state, and hover/focus;
- join fields/errors, payment and slot picker, Clerk sign-in containment;
- member cards/actions and every admin section/table/drawer;
- at 1280 and 1440, every unselected collection table uses the full content
  width: no empty detail pane and no wide table squeezed into a narrow rail;
  after selection, both master and detail remain usable;
- no content-width background stripe, split canvas, or abrupt backdrop seam
  appears around a viewport-width workspace. Inspect computed background,
  padding, min-height, and overflow on every ancestor between the host mount and
  the workspace—including theme scopes and embedded shells. A `100vw` child can
  escape a centered max-width box while one of those ancestors still paints the
  centered box behind it;
- record the CSS-pixel bounding boxes for the accepted outer workspace, master,
  and detail at desktop widths. Compare those measurements with the frozen
  baseline; static markup and component identity cannot prove geometry;
- no clipped labels, card text escape, accidental document scroll, or
  horizontal overflow;
- loading, empty, error, unauthorized, 404, and reduced-motion states.

The human approves deployed screenshots/browser behavior. Passing CSS tests is
not visual parity.

## Phase 6 — Provider and authorization parity

### Clerk

For the one website being converted, retain that website's existing Clerk
application/workspace unless the human approves an identity migration. A
leader and follower are different websites and use different Clerk
applications, publishable keys, issuers, roles, and local session tokens. A
Clerk JWT never authenticates a cross-site delivery.

Prefer explicit `auth: { source: "clerk", superAdminSource: "odla" }` for
backend-only authorization. It resolves `private_metadata.role` from Clerk on
each check and never falls back to public metadata or a session role claim.
Legacy claim mode requires session claims for both email and role; hub table
mode uses lowercase `admins` rows. Prove signed-out, allowed, forbidden,
provisional, member, admin, super-admin, malformed, expired, wrong-issuer,
sign-out, and return-target behavior. If the site's verifier intentionally
enforces JWT `aud` or `azp`, retain that check with a host verifier until
Chapter exposes the same policy and add wrong-audience/wrong-authorized-party
fixtures. If it never enforced those claims, mark those two cases `n/a` only
after the full matrix is recorded; do not call their absence an auth success or
use it to skip the remaining authorization tests.

When Chapter needs server-side account/role operations, use the existing
environment-scoped reserved credential (Chapter reads its effective
`clerk_secret_key` alias):

```sh
npx odla-ai secrets set-clerk-key --env dev --stdin
```

Do not create a second secret pair. Confirm the selected instance and dev
`sk_test_` status without printing the secret; never put `sk_live_` in dev.

#### Coordinated dev private-role cutover

1. Resolve every active runtime sharing the app's dev Clerk instance from odla.
   All developer sandboxes are authoritative; do not infer the inventory from
   one checkout or change a peer's deployment without authority.
2. Have the human grant an existing operator's exact Clerk subject the protected
   app-scoped role through odla Studio → Database → Users. Confirm an active,
   nondeleted `$users` row. Never copy a legacy `superAdmins` row, email match,
   or Clerk metadata value into a protected grant. Keep its ordinary Clerk
   admin role separate. Do not switch live auth with no protected operator.
3. Stage compatible private-role readers AND writers in every runtime. Pause
   role-changing approval/refund/seat/admin operations everywhere during
   migration; do not leave a legacy writer racing a private writer.
4. Backend-read all Clerk users and run `planPrivateRoleMigration` with the exact
   dev inventory, reviewed runtime versions/readiness, and existing protected
   subject IDs. Resolve malformed/unknown/conflicting roles before proceeding.
   The helper is dry-run only; a ready result is not a remote lock or write grant.
5. For each reviewed change, re-read and compare both role fields immediately
   before the metadata PATCH. If either changed, stop and regenerate the plan.
   Merge the approved role into `private_metadata.role`, removing only the old
   public role key; preserve unrelated metadata. Re-read to verify each result.
   Keep writers paused throughout; regenerate the plan on interrupted resume.
6. Switch all participating runtimes to the private configuration together and
   verify admin/member access, denied stale/public-only admin claims, exact-ID
   protected authority, and same-session promotion/revocation. Remove the unused
   public role session claim only after every relying runtime is migrated.
   Exercise approval, refund, seat, and admin role changes against the same
   private field before resuming normal writes.
7. Do not roll back only the Worker to a public-role reader after metadata has
   migrated. Keep writes paused and review a coordinated recovery using fresh
   provider state. Never replay a stale role snapshot or automatically recreate
   public privileges. Old allowlist rows may remain stored but have no authority
   in protected mode; deleting them is not required for this cutover.

Chapter now reserves `public_metadata` for the small authorization role and
stores its `applicationId`/allowlisted profile snapshot in backend-only
`private_metadata`. After deploying the schema update, run the authenticated
admin repair endpoint in bounded batches:

```text
POST /api/admin/clerk/private-profiles/sync?offset=0&limit=50
```

Continue with each returned `nextOffset` until it is `null`. Prove that the
public `role` and unrelated host metadata survive, the former public
`applicationId`/`profile` keys are absent, the private snapshot matches the
latest application, and `clerkPrivateMetadataSyncedAt` plus `clerkUserId` are
recorded locally. The application row and CRM remain canonical; this is an
account/admin signal mirror, not a third editable profile database.

### Stripe

Use test resources and an isolated dev webhook. Store `stripe_secret_key` and
`stripe_webhook_secret` write-only; reconcile group `stripePublishableKey` and
`stripePriceId`. Read that exact Stripe Price from Stripe and prove its first
charge, recurring amount, currency, and interval match the rendered and
approved contract. `paymentsReady: true` proves neither that equality nor
webhook readiness; Chapter's built-in money formatter is USD/dollar-specific in
this release. Preserve a host UI/route for non-USD or mismatched pricing. Test
successful payment, duplicate webhook, failure, refund, and subscription
cancellation before switching the UI.

For a shared Stripe account, preserve Chapter's closed partition metadata on
every new customer, subscription, payment intent, and refund: app, chapter,
environment, data environment, and stable runtime. Do not infer ownership from
the Stripe account or Price alone. A Worker with a named runtime prefers its
`stripe_webhook_secret__<runtime>` endpoint secret. During an existing app's
upgrade, Chapter falls back to the historical `stripe_webhook_secret` slot only
when the scoped slot is absent; replace that compatibility path by reconciling a
dedicated endpoint, without reading or manually copying either secret. The
signed webhook must apply an exact target
once, acknowledge a fully tagged sibling with zero local writes, quarantine an
unmatched event for operators, and accept a metadata-free legacy object only
when its Stripe customer, subscription, or gift id is already linked to this
chapter and runtime. Exercise all four paths in development, including a replay
of the identical body and an event-id collision with changed content, before
removing any legacy payment adapter.

### Calendar and email

Complete dev Google booking consent, reconnecting any grant from the retired
read-only mirror, then prove actual slots, booking, rebooking, cancellation,
and invitation behavior. `schedulingReady: false` with HTTP 200 is a failed
readiness gate, not a pass.

Use a verified dev sender plus `debugEmail`; prove every lifecycle template,
recipient redirect, replay deduplication, concurrent-send behavior, and the
selected account invitation effect. Never let dev send to imported members.

## Phase 7 — Full deployed-dev journey

Check in an executable acceptance manifest with:

- actual dev URLs and immutable Worker version ids, paired with the source
  commit they are expected to run;
- deterministic synthetic member/application ids;
- expected route owners and full request/response contracts—not only paths,
  statuses, or equal values—plus schema/counts/freshness and Chapter backend
  marker;
- expected migration-readiness inputs and a `200` only when each is green;
- expected account, payment, booking, email, CRM, and admin outcomes;
- expected o11y service/release and safe trace;
- replay and failure-injection outcomes;
- visual viewport/theme fixtures.

Run the real journey:

1. browse every public route/deep link and verify SEO/404/method behavior;
2. submit the configured join form, including consent;
3. execute Stripe test payment and authoritative webhook;
4. book/rebook the intro call and receive the debug-routed email;
5. sign in as provisional/member/admin and use the real member/admin pages;
6. perform every admin mutation family and verify Chapter-primary audit plus
   legacy rollback mirror;
7. replay the event and prove no duplicate row, charge, booking, account, or
   email;
8. inject ODLA/provider/mirror failure, observe explicit failure/retry, recover;
9. verify freshness/continuous-sync budget and visual parity;
10. require the fail-closed migration-readiness gate to return `200`;
11. follow safe o11y evidence across the real Worker.

`doctor`, unit tests, build, CLI smoke, a login page, and a human-looking admin
screen are necessary but not sufficient.

### Close the source-to-deployment loop

A commit, pushed branch, or merged pull request does not change a running
website. After every change that affects a route, workspace, asset, provider
binding, or acceptance result:

1. identify the exact reviewed commit and intended deployment target;
2. build and deploy that commit with the repository's reviewed dev command;
3. capture the deploy command, direct origin, immutable Worker/deployment
   version, and source commit in PM;
4. reload the direct deployed origin and assert distinctive behavior from the
   acceptance matrix—not merely a shared label or route;
5. measure the deployed viewport geometry, inspect the computed styles of every
   layout ancestor involved in a breakout, and exercise the affected journey;
   source CSS, selector-presence tests, and static markup do not prove which
   layer paints the deployed page;
6. leave the bug/task open if the intended commit was not deployed or the live
   assertion was not observed.

Do not report “fixed”, “ready for handoff”, or a passing phase from source-only
tests. If CI is expected to deploy a branch or merge automatically, verify the
actual completed deployment and version rather than assuming the trigger ran.

Before filing a route bug from deployed evidence, prove that the probed
deployment runs the intended commit/version. Repeat the request against the
direct candidate origin and the public domain with a unique non-secret query
value, capture `Age`, `Cache-Control`, `CF-Cache-Status`, `ETag`, and the Worker
version marker, and re-test after the documented edge/config propagation
window. A cached pre-deploy or pre-credential `404` is not evidence that the
current route is absent.

## Phase 8 — Production parallel run and cutover

Do not add production until the human approves the full dev report and both
rollback plans.

1. Add only the literal `prod` environment using the production instance of the
   same Clerk app, Stripe live resources, approved email sender, calendars,
   links, and distinct secret targets. Do not use the CLI-valid alias
   `production`: Chapter would suppress or debug-redirect lifecycle mail.
2. Run production build/tests/security scan, `doctor`, and
   `provision --dry-run`; inspect CI/Workers Builds so merging cannot
   auto-deploy the legacy production target unexpectedly.
3. After explicit approval, provision with `--yes` and deploy a production
   Chapter candidate off-route. Record its version id.
4. Repeat historical backfill, reconciliation, continuous sync, shadow reads,
   provider checks, and a production-safe synthetic journey against production
   source data. Dev data is not a production backfill.
5. At one checkpoint, require the fail-closed readiness gate to return `200`,
   then switch production reads. Verify freshness, auth, visual behavior, and
   explicit failure handling while legacy writes continue.
6. At a second checkpoint, record a write high-water mark, require readiness
   again, and make Chapter authoritative for writes. Keep the durable legacy
   rollback mirror and continuously reconcile it.
7. Abort when write loss, unbounded lag, unexplained diff, auth failure,
   freshness breach, or accepted error budget is crossed.

### Runtime rollback

Restore the recorded known-good Worker version plus routes, bindings, triggers,
and domains. Verify representative routes and health. Keep Chapter resources
and telemetry for investigation; do not delete them.

### Data rollback

Pause/drain new Chapter-primary work; enumerate accepted writes since the
checkpoint; reverse-project missing writes with stable idempotency keys;
reconcile queues, counts, timestamps, identities, status, meetings, charges,
and email; only then report legacy reads healthy. Never reset either store.

Keep both rollback capabilities through the approved observation window
(normally at least 72 hours). Retire each legacy reader, writer, binding,
webhook, job, and secret only in a separate human-approved change with a fresh
journey afterward.

Mark the migration goals met and tasks done only when every applicable track is
`primary-prod` or `retired`, the observation window passes, evidence is attached
in PM, and the human confirms the existing product—not merely a Chapter
canary—has been converted.
